from django.apps import AppConfig


class AliappConfig(AppConfig):
    name = 'aliapp'
